package com.holdmylua.source.scripting.custom_api;

import com.holdmylua.source.annotation.Safe;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;

public class KeyBindManager {
   KeyMapping key;

   /**
    * Lua scripts (and the bundled packs) pass GLFW key codes, e.g. 67 = C. Minecraft 26.3
    * replaced GLFW with SDL3 and key mappings are now SDL scancodes, so the GLFW code is
    * translated here to keep existing scripts working unchanged.
    */
   @Safe
   public boolean isKeyPressed(int keyCode) {
      if (keyCode != 0) {
         int scancode = glfwToSdlScancode(keyCode);
         if (scancode <= 0) {
            return false;
         }
         return InputConstants.isKeyDown(Minecraft.getInstance().getWindow(), scancode);
      } else {
         return false;
      }
   }

   private static int glfwToSdlScancode(int glfw) {
      if (glfw >= 65 && glfw <= 90) return 4 + (glfw - 65);   // A-Z
      if (glfw >= 49 && glfw <= 57) return 30 + (glfw - 49);  // 1-9
      if (glfw == 48) return 39;                              // 0
      if (glfw >= 290 && glfw <= 301) return 58 + (glfw - 290); // F1-F12
      if (glfw >= 320 && glfw <= 329) return glfw == 320 ? 98 : 89 + (glfw - 321); // keypad 0-9
      switch (glfw) {
         case 32: return 44;   // space
         case 39: return 52;   // '
         case 44: return 54;   // ,
         case 45: return 45;   // -
         case 46: return 55;   // .
         case 47: return 56;   // /
         case 59: return 51;   // ;
         case 61: return 46;   // =
         case 91: return 47;   // [
         case 92: return 49;   // backslash
         case 93: return 48;   // ]
         case 96: return 53;   // `
         case 256: return 41;  // escape
         case 257: return 40;  // enter
         case 258: return 43;  // tab
         case 259: return 42;  // backspace
         case 260: return 73;  // insert
         case 261: return 76;  // delete
         case 262: return 79;  // right
         case 263: return 80;  // left
         case 264: return 81;  // down
         case 265: return 82;  // up
         case 266: return 75;  // page up
         case 267: return 78;  // page down
         case 268: return 74;  // home
         case 269: return 77;  // end
         case 340: return 225; // left shift
         case 341: return 224; // left ctrl
         case 342: return 226; // left alt
         case 344: return 229; // right shift
         case 345: return 228; // right ctrl
         case 346: return 230; // right alt
         default: return -1;
      }
   }
}
